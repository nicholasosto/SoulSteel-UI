# SoulSteel UI Kit

Stand‑alone Roblox‑TS/Fusion UI library for the *Soul Steel* project.

## Quick start

```bash
npm install
rbxtsc -w & rojo serve default.project.json
```

Mount `ReplicatedStorage.UI.Organisms.EquipmentPanel` in any client script to preview.
