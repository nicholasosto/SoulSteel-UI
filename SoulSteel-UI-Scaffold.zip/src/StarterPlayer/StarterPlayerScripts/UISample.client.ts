import Fusion from "@rbxts/fusion";
import { EquipmentPanel } from "ReplicatedStorage/UI/Organisms/EquipmentPanel";

const { New, Children } = Fusion;

const playerGui = game.GetService("Players").LocalPlayer!.WaitForChild("PlayerGui") as PlayerGui;

const screen = New("ScreenGui")({
    Name: "UIKitTest",
    ResetOnSpawn: false,
    IgnoreGuiInset: true,
    Parent: playerGui,

    [Children]: {
        Panel: EquipmentPanel(),
    },
});
